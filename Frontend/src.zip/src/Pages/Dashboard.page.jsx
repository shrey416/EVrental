import Dashboard from "../Components/Dashboard";
import React from "react";

function DashboardPage() {
  return <Dashboard />;
}

export default DashboardPage;